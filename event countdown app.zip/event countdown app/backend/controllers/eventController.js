const Event = require('../models/schema');

// Get all events for a user
const getEvents = async (req, res) => {
    try {
        const userId = req.query.userId;
        const events = await Event.find({
            $or: [
                { createdBy: userId },
                { isPublic: true }
            ]
        });
        res.json(events);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Get a single event
const getEvent = async (req, res) => {
    try {
        const event = await Event.findById(req.params.id);
        if (!event) {
            return res.status(404).json({ message: 'Event not found' });
        }

        // Allow access if event is public or user is the creator
        if (event.isPublic || event.createdBy === req.query.userId) {
            res.json(event);
        } else {
            res.status(403).json({ message: 'Not authorized to view this event' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Create a new event
const createEvent = async (req, res) => {
    try {
        const eventData = {
            ...req.body,
            createdBy: req.body.createdBy || req.body.userId || 'anonymous'
        };
        delete eventData.userId;

        const event = new Event(eventData);
        const newEvent = await event.save();

        // If the event is public, generate share link
        if (newEvent.isPublic && !newEvent.shareLink) {
            newEvent.shareLink = `${newEvent._id}-${Math.random().toString(36).substring(2, 8)}`;
            await newEvent.save();
        }

        res.status(201).json(newEvent);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

// Update an event
const updateEvent = async (req, res) => {
    try {
        const event = await Event.findById(req.params.id);
        if (!event) {
            return res.status(404).json({ message: 'Event not found' });
        }
        
        if (event.createdBy !== req.body.userId) {
            return res.status(403).json({ message: 'Not authorized' });
        }

        // If making the event public, generate share link
        if (req.body.isPublic && !event.shareLink) {
            event.shareLink = `${event._id}-${Math.random().toString(36).substring(2, 8)}`;
        }

        Object.assign(event, req.body);
        const updatedEvent = await event.save();
        res.json(updatedEvent);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

// Delete an event
const deleteEvent = async (req, res) => {
    try {
        const event = await Event.findById(req.params.id);
        if (!event) {
            return res.status(404).json({ message: 'Event not found' });
        }

        if (event.createdBy !== req.query.userId) {
            return res.status(403).json({ message: 'Not authorized' });
        }

        await event.deleteOne();
        res.json({ message: 'Event deleted' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Get event by share link
const getEventByShareLink = async (req, res) => {
    try {
        const event = await Event.findOne({ shareLink: req.params.shareLink });
        if (!event) {
            return res.status(404).json({ message: 'Event not found' });
        }
        if (!event.isPublic) {
            return res.status(403).json({ message: 'This event is private' });
        }
        res.json(event);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Update milestone status
const updateMilestone = async (req, res) => {
    try {
        const event = await Event.findById(req.params.eventId);
        if (!event) {
            return res.status(404).json({ message: 'Event not found' });
        }

        const milestone = event.milestones.id(req.params.milestoneId);
        if (!milestone) {
            return res.status(404).json({ message: 'Milestone not found' });
        }

        milestone.completed = req.body.completed;
        await event.save();
        res.json(event);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

module.exports = {
    getEvents,
    getEvent,
    createEvent,
    updateEvent,
    deleteEvent,
    getEventByShareLink,
    updateMilestone
};
