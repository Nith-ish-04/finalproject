const express = require('express');
const router = express.Router();
const {
    getEvents,
    createEvent,
    updateEvent,
    deleteEvent,
    getEventByShareLink,
    updateMilestone
} = require('../controllers/eventController');

// Event routes
router.get('/', getEvents);
router.post('/', createEvent);
router.put('/:id', updateEvent);
router.delete('/:id', deleteEvent);
router.get('/share/:shareLink', getEventByShareLink);
router.patch('/:eventId/milestones/:milestoneId', updateMilestone);

module.exports = router;
