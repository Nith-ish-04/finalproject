const express = require('express');
const cors = require('cors');
const connectDB = require('./DB/db');
const eventController = require('./controllers/eventController');

require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Connect to MongoDB
const startServer = async () => {
    try {
        await connectDB();
        
        // Middleware
        app.use(cors());
        app.use(express.json());

        // Routes
        app.get('/api/events/share/:shareLink', eventController.getEventByShareLink);  // Specific route first
        app.get('/api/events/:id', eventController.getEvent);  // Then generic routes
        app.get('/api/events', eventController.getEvents);
        app.post('/api/events', eventController.createEvent);
        app.put('/api/events/:id', eventController.updateEvent);
        app.delete('/api/events/:id', eventController.deleteEvent);
        app.patch('/api/events/:eventId/milestones/:milestoneId', eventController.updateMilestone);

        // Error handling middleware
        app.use((err, req, res, next) => {
            console.error(err.stack);
            res.status(500).json({ message: 'Something went wrong!' });
        });

        // Start server with port retry logic
        const server = app.listen(PORT, () => {
            console.log(`Server is running on port ${PORT}`);
        });

        server.on('error', (error) => {
            if (error.code === 'EADDRINUSE') {
                console.log(`Port ${PORT} is busy, trying ${PORT + 1}...`);
                server.listen(PORT + 1);
            } else {
                console.error('Server error:', error);
                process.exit(1);
            }
        });
    } catch (error) {
        console.error('Failed to start server:', error);
        process.exit(1);
    }
};

// Handle uncaught errors
process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
    process.exit(1);
});

process.on('unhandledRejection', (error) => {
    console.error('Unhandled Rejection:', error);
    process.exit(1);
});

startServer();
