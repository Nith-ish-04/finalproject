const mongoose = require('mongoose');
const crypto = require('crypto');

const milestoneSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  dueDate: {
    type: Date,
    required: true
  },
  completed: {
    type: Boolean,
    default: false
  }
});

const eventSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  description: {
    type: String
  },
  date: {
    type: Date,
    required: true
  },
  theme: {
    backgroundColor: {
      type: String,
      default: '#ffffff'
    },
    textColor: {
      type: String,
      default: '#000000'
    },
    animation: {
      type: String,
      default: 'fade'
    }
  },
  milestones: {
    type: [milestoneSchema]
  },
  createdBy: {
    type: String,
    default: 'anonymous'
  },
  isPublic: {
    type: Boolean,
    default: false
  },
  shareLink: {
    type: String
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Generate share link before saving if event is public
eventSchema.pre('save', function(next) {
  if (this.isPublic && !this.shareLink) {
    this.shareLink = crypto.randomBytes(8).toString('hex');
  }
  next();
});

const Event = mongoose.model('Event', eventSchema);

module.exports = Event;