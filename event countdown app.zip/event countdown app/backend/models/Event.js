const mongoose = require('mongoose');

const milestoneSchema = new mongoose.Schema({
    title: { type: String, required: true },
    dueDate: { type: Date, required: true },
    completed: { type: Boolean, default: false }
});

const eventSchema = new mongoose.Schema({
    title: { type: String, required: true },
    description: { type: String },
    date: { type: Date, required: true },
    theme: {
        backgroundColor: { type: String, default: '#ffffff' },
        textColor: { type: String, default: '#000000' },
        backgroundImage: { type: String },
        animation: { type: String, default: 'fade' }
    },
    milestones: [milestoneSchema],
    createdBy: { type: String, required: true },
    isPublic: { type: Boolean, default: false },
    shareLink: { type: String },
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

// Create a unique share link before saving
eventSchema.pre('save', function(next) {
    if (!this.shareLink) {
        this.shareLink = `${this._id}-${Math.random().toString(36).substring(2, 8)}`;
    }
    this.updatedAt = Date.now();
    next();
});

module.exports = mongoose.model('Event', eventSchema);
