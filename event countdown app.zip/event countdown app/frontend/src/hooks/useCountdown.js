import { useState, useEffect } from 'react';
import useNotification from './useNotification';

export const useCountdown = (targetDate) => {
  const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());
  const [isExpired, setIsExpired] = useState(false);
  const { sendNotification } = useNotification();

  function calculateTimeLeft() {
    const difference = new Date(targetDate).getTime() - new Date().getTime();
    let timeLeft = {};

    if (difference > 0) {
      timeLeft = {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
      };
    }

    return timeLeft;
  }

  useEffect(() => {
    const timer = setInterval(() => {
      const newTimeLeft = calculateTimeLeft();
      setTimeLeft(newTimeLeft);

      // Check if countdown just finished
      if (Object.keys(newTimeLeft).length === 0 && !isExpired) {
        setIsExpired(true);
        sendNotification('Event Time is Up!', {
          body: 'Your event has reached its countdown target.',
          vibrate: [200, 100, 200],
        });
        clearInterval(timer);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [targetDate, isExpired, sendNotification]);

  return { timeLeft, isExpired };
};

export default useCountdown;
