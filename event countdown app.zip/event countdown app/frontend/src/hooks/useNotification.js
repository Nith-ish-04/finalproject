import { useState, useEffect } from 'react';

const useNotification = () => {
  const [permission, setPermission] = useState(Notification.permission);

  const requestPermission = async () => {
    try {
      const result = await Notification.requestPermission();
      setPermission(result);
      return result;
    } catch (error) {
      console.error('Error requesting notification permission:', error);
      return 'denied';
    }
  };

  const sendNotification = (title, options = {}) => {
    if (permission === 'granted') {
      try {
        const notification = new Notification(title, {
          icon: '/vite.svg', // You can replace this with your app icon
          ...options,
        });

        notification.onclick = () => {
          window.focus();
          notification.close();
        };
      } catch (error) {
        console.error('Error sending notification:', error);
      }
    }
  };

  useEffect(() => {
    if (permission === 'default') {
      requestPermission();
    }
  }, []);

  return { permission, requestPermission, sendNotification };
};

export default useNotification;
