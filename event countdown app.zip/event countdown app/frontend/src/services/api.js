// Get the API URL from environment variable or default to localhost
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Helper function to handle API responses
const handleResponse = async (response) => {
    const data = await response.json();
    if (!response.ok) {
        throw new Error(data.message || 'Something went wrong');
    }
    return data;
};

// Get all events for a user
export const getEvents = async (userId) => {
    try {
        const response = await fetch(`${API_URL}/events?userId=${userId}`);
        return handleResponse(response);
    } catch (error) {
        throw new Error(error.message);
    }
};

// Get a single event
export const getEvent = async (id) => {
    try {
        const response = await fetch(`${API_URL}/events/${id}`);
        return handleResponse(response);
    } catch (error) {
        throw new Error(error.message);
    }
};

// Create a new event
export const createEvent = async (eventData) => {
    try {
        // Ensure userId is set
        const userId = eventData.userId || localStorage.getItem('userId');
        if (!userId) {
            throw new Error('User ID is required');
        }

        const response = await fetch(`${API_URL}/events`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                ...eventData,
                createdBy: userId // Set createdBy to userId
            }),
        });
        return handleResponse(response);
    } catch (error) {
        throw new Error(error.message);
    }
};

// Update an event
export const updateEvent = async (id, eventData) => {
    try {
        const response = await fetch(`${API_URL}/events/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                ...eventData,
                userId: localStorage.getItem('userId')
            }),
        });
        return handleResponse(response);
    } catch (error) {
        throw new Error(error.message);
    }
};

// Delete an event
export const deleteEvent = async (id) => {
    try {
        const userId = localStorage.getItem('userId');
        const response = await fetch(`${API_URL}/events/${id}?userId=${userId}`, {
            method: 'DELETE',
        });
        return handleResponse(response);
    } catch (error) {
        throw new Error(error.message);
    }
};

// Update milestone status
export const updateMilestone = async (eventId, milestoneId, completed) => {
    try {
        const response = await fetch(`${API_URL}/events/${eventId}/milestones/${milestoneId}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                completed,
                userId: localStorage.getItem('userId')
            }),
        });
        return handleResponse(response);
    } catch (error) {
        throw new Error(error.message);
    }
};

// Get event by share link
export const getEventByShareLink = async (shareLink) => {
    try {
        const response = await fetch(`${API_URL}/events/share/${shareLink}`);
        return handleResponse(response);
    } catch (error) {
        throw new Error(error.message);
    }
};
