import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  VStack,
  FormControl,
  FormLabel,
  Input,
  Textarea,
  Button,
  useToast,
  Switch,
  HStack,
  Text,
  IconButton,
  Divider,
} from '@chakra-ui/react';
import { AddIcon, DeleteIcon } from '@chakra-ui/icons';
import { createEvent } from '../services/api';

const CreateEvent = () => {
  const navigate = useNavigate();
  const toast = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    date: '',
    isPublic: false,
    milestones: [],
    theme: {
      backgroundColor: '#ffffff',
      textColor: '#000000'
    }
  });

  useEffect(() => {
    // Generate a random userId if not exists
    if (!localStorage.getItem('userId')) {
      localStorage.setItem('userId', 'user_' + Math.random().toString(36).substr(2, 9));
    }
  }, []);

  const [newMilestone, setNewMilestone] = useState({
    title: '',
    dueDate: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleThemeChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      theme: {
        ...prev.theme,
        [name]: value
      }
    }));
  };

  const handlePublicToggle = () => {
    setFormData(prev => ({
      ...prev,
      isPublic: !prev.isPublic
    }));
  };

  const handleMilestoneInputChange = (e) => {
    const { name, value } = e.target;
    setNewMilestone(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const addMilestone = () => {
    if (!newMilestone.title || !newMilestone.dueDate) {
      toast({
        title: 'Missing fields',
        description: 'Please fill in both title and due date for the milestone',
        status: 'warning',
        duration: 3000,
      });
      return;
    }

    setFormData(prev => ({
      ...prev,
      milestones: [...prev.milestones, { ...newMilestone }]
    }));

    setNewMilestone({
      title: '',
      dueDate: ''
    });
  };

  const removeMilestone = (index) => {
    setFormData(prev => ({
      ...prev,
      milestones: prev.milestones.filter((_, i) => i !== index)
    }));
  };

  const validateForm = () => {
    if (!formData.title) {
      toast({
        title: 'Title is required',
        status: 'error',
        duration: 3000,
      });
      return false;
    }
    if (!formData.date) {
      toast({
        title: 'Date is required',
        status: 'error',
        duration: 3000,
      });
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      // Format the data
      const eventData = {
        ...formData,
        date: new Date(formData.date).toISOString(),
        milestones: formData.milestones.map(m => ({
          ...m,
          dueDate: new Date(m.dueDate).toISOString()
        })),
        userId: localStorage.getItem('userId') // Add userId here
      };
      
      console.log('Submitting event data:', eventData);
      const response = await createEvent(eventData);
      console.log('Event created:', response);

      toast({
        title: 'Event created successfully',
        status: 'success',
        duration: 3000,
      });
      navigate('/');
    } catch (error) {
      console.error('Error in form submission:', error);
      toast({
        title: 'Error creating event',
        description: error.message,
        status: 'error',
        duration: 3000,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box maxW="800px" mx="auto" p={6}>
      <form onSubmit={handleSubmit}>
        <VStack spacing={6} align="stretch">
          <FormControl isRequired>
            <FormLabel>Event Title</FormLabel>
            <Input
              name="title"
              value={formData.title}
              onChange={handleInputChange}
              placeholder="Enter event title"
            />
          </FormControl>

          <FormControl>
            <FormLabel>Description</FormLabel>
            <Textarea
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              placeholder="Enter event description"
            />
          </FormControl>

          <FormControl isRequired>
            <FormLabel>Event Date</FormLabel>
            <Input
              name="date"
              type="datetime-local"
              value={formData.date}
              onChange={handleInputChange}
              min={new Date().toISOString().slice(0, 16)}
            />
          </FormControl>

          <FormControl>
            <HStack justify="space-between">
              <FormLabel mb="0">Make Event Public</FormLabel>
              <Switch
                isChecked={formData.isPublic}
                onChange={handlePublicToggle}
                colorScheme="purple"
              />
            </HStack>
          </FormControl>

          <Divider />

          <Box>
            <Text fontSize="lg" fontWeight="bold" mb={4}>
              Milestones (Optional)
            </Text>
            
            <VStack spacing={4} align="stretch" mb={4}>
              {formData.milestones.map((milestone, index) => (
                <HStack key={index} p={2} borderWidth="1px" borderRadius="md">
                  <VStack align="stretch" flex={1}>
                    <Text fontWeight="bold">{milestone.title}</Text>
                    <Text fontSize="sm">
                      Due: {new Date(milestone.dueDate).toLocaleDateString()}
                    </Text>
                  </VStack>
                  <IconButton
                    icon={<DeleteIcon />}
                    onClick={() => removeMilestone(index)}
                    colorScheme="red"
                    variant="ghost"
                  />
                </HStack>
              ))}
            </VStack>

            <VStack spacing={4} align="stretch">
              <FormControl>
                <FormLabel>Milestone Title</FormLabel>
                <Input
                  name="title"
                  value={newMilestone.title}
                  onChange={handleMilestoneInputChange}
                  placeholder="Enter milestone title"
                />
              </FormControl>

              <FormControl>
                <FormLabel>Due Date</FormLabel>
                <Input
                  name="dueDate"
                  type="datetime-local"
                  value={newMilestone.dueDate}
                  onChange={handleMilestoneInputChange}
                  min={new Date().toISOString().slice(0, 16)}
                />
              </FormControl>

              <Button
                leftIcon={<AddIcon />}
                onClick={addMilestone}
                colorScheme="purple"
                variant="outline"
              >
                Add Milestone
              </Button>
            </VStack>
          </Box>

          <Divider />

          <FormControl>
            <FormLabel>Background Color</FormLabel>
            <Input
              name="backgroundColor"
              type="color"
              value={formData.theme.backgroundColor}
              onChange={handleThemeChange}
            />
          </FormControl>

          <FormControl>
            <FormLabel>Text Color</FormLabel>
            <Input
              name="textColor"
              type="color"
              value={formData.theme.textColor}
              onChange={handleThemeChange}
            />
          </FormControl>

          <Button
            type="submit"
            colorScheme="purple"
            size="lg"
            isLoading={loading}
          >
            Create Event
          </Button>
        </VStack>
      </form>
    </Box>
  );
};

export default CreateEvent;
