import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  VStack,
  Heading,
  Text,
  Button,
  useToast,
  HStack,
  IconButton,
  Badge,
  Input,
  InputGroup,
  InputRightElement,
  Alert,
  AlertIcon,
  Progress,
  SimpleGrid,
  Checkbox,
  Flex,
} from '@chakra-ui/react';
import { DeleteIcon, CopyIcon, ExternalLinkIcon } from '@chakra-ui/icons';
import useCountdown from '../hooks/useCountdown';
import { getEvent, deleteEvent, updateMilestone } from '../services/api';

const EventDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const [event, setEvent] = useState(null);
  const [showShareLink, setShowShareLink] = useState(false);
  const [loading, setLoading] = useState(true);
  const { timeLeft, isExpired } = useCountdown(event?.date);

  useEffect(() => {
    const fetchEvent = async () => {
      try {
        const data = await getEvent(id);
        setEvent(data);
      } catch (error) {
        toast({
          title: 'Error fetching event',
          description: error.message,
          status: 'error',
          duration: 3000,
        });
        navigate('/');
      } finally {
        setLoading(false);
      }
    };
    fetchEvent();
  }, [id, navigate, toast]);

  const handleDelete = async () => {
    try {
      await deleteEvent(id);
      toast({
        title: 'Event deleted',
        status: 'success',
        duration: 3000,
      });
      navigate('/');
    } catch (error) {
      toast({
        title: 'Error deleting event',
        description: error.message,
        status: 'error',
        duration: 3000,
      });
    }
  };

  const getShareLink = () => {
    const baseUrl = window.location.origin;
    return `${baseUrl}/share/${event._id}`;
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(getShareLink());
    toast({
      title: 'Link copied!',
      description: 'Share this link with others to view the countdown',
      status: 'success',
      duration: 2000,
    });
  };

  const handleMilestoneToggle = async (milestoneId, completed) => {
    try {
      await updateMilestone(event._id, milestoneId, completed);
      setEvent((prev) => ({
        ...prev,
        milestones: prev.milestones.map((m) =>
          m._id === milestoneId ? { ...m, completed } : m
        ),
      }));
    } catch (error) {
      toast({
        title: 'Error updating milestone',
        description: error.message,
        status: 'error',
        duration: 3000,
      });
    }
  };

  if (loading) {
    return <Text>Loading...</Text>;
  }

  if (!event) {
    return <Text>Event not found</Text>;
  }

  const formatTimeValue = (value, unit) => {
    if (!value && value !== 0) return '';
    return `${value} ${unit}${value === 1 ? '' : 's'}`;
  };

  const getTimeString = () => {
    if (isExpired) {
      return 'Event has ended';
    }

    const timeStrings = [];
    if (timeLeft.days) timeStrings.push(formatTimeValue(timeLeft.days, 'day'));
    if (timeLeft.hours) timeStrings.push(formatTimeValue(timeLeft.hours, 'hour'));
    if (timeLeft.minutes) timeStrings.push(formatTimeValue(timeLeft.minutes, 'minute'));
    if (timeLeft.seconds) timeStrings.push(formatTimeValue(timeLeft.seconds, 'second'));

    return timeStrings.join(', ') || 'Now';
  };

  return (
    <Box
      maxW="800px"
      mx="auto"
      p={6}
      bg={event.theme?.backgroundColor || 'white'}
      color={event.theme?.textColor || 'black'}
      borderRadius="lg"
      shadow="md"
    >
      <VStack spacing={6} align="stretch">
        <HStack justify="space-between">
          <Heading size="lg">{event.title}</Heading>
          <HStack>
            {event.isPublic && (
              <IconButton
                icon={<ExternalLinkIcon />}
                onClick={() => setShowShareLink(!showShareLink)}
                aria-label="Share event"
                colorScheme="purple"
                variant="ghost"
              />
            )}
            <IconButton
              icon={<ExternalLinkIcon />}
              onClick={() => navigator.clipboard.writeText(getShareLink())}
              aria-label="Copy share link"
              colorScheme="purple"
              variant="ghost"
            />
            <IconButton
              icon={<DeleteIcon />}
              onClick={handleDelete}
              aria-label="Delete event"
              colorScheme="red"
              variant="ghost"
            />
          </HStack>
        </HStack>

        {event.isPublic && showShareLink && (
          <Box>
            <Alert status="info" mb={3}>
              <AlertIcon />
              This is a public event. Share the link below with anyone to view the countdown.
            </Alert>
            <InputGroup>
              <Input value={getShareLink()} isReadOnly />
              <InputRightElement>
                <IconButton
                  icon={<CopyIcon />}
                  onClick={handleCopyLink}
                  aria-label="Copy share link"
                  size="sm"
                />
              </InputRightElement>
            </InputGroup>
          </Box>
        )}

        <Text>{event.description}</Text>

        <Box>
          <Text fontSize="sm" mb={1}>Time Remaining:</Text>
          <Text fontSize="2xl" fontWeight="bold" color={isExpired ? 'red.500' : 'inherit'}>
            {getTimeString()}
          </Text>
          <Progress value={(timeLeft.total / (event.date - new Date())) * 100} size="lg" colorScheme="purple" mb={4} />
          <SimpleGrid columns={4} spacing={4}>
            <Box>
              <Text fontSize="4xl" fontWeight="bold">
                {timeLeft.days}
              </Text>
              <Text>Days</Text>
            </Box>
            <Box>
              <Text fontSize="4xl" fontWeight="bold">
                {timeLeft.hours}
              </Text>
              <Text>Hours</Text>
            </Box>
            <Box>
              <Text fontSize="4xl" fontWeight="bold">
                {timeLeft.minutes}
              </Text>
              <Text>Minutes</Text>
            </Box>
            <Box>
              <Text fontSize="4xl" fontWeight="bold">
                {timeLeft.seconds}
              </Text>
              <Text>Seconds</Text>
            </Box>
          </SimpleGrid>
        </Box>

        {event.milestones?.length > 0 && (
          <Box>
            <Heading size="md" mb={3}>Milestones</Heading>
            <VStack align="stretch" spacing={3}>
              {event.milestones.map((milestone, index) => (
                <Flex
                  key={index}
                  justify="space-between"
                  align="center"
                  p={3}
                  borderWidth="1px"
                  borderRadius="md"
                  bg={event.theme?.backgroundColor || 'white'}
                >
                  <Checkbox
                    isChecked={milestone.completed}
                    onChange={(e) =>
                      handleMilestoneToggle(milestone._id, e.target.checked)
                    }
                  >
                    <Text ml={2}>{milestone.title}</Text>
                  </Checkbox>
                  <Text fontSize="sm">
                    Due: {new Date(milestone.dueDate).toLocaleDateString()}
                  </Text>
                </Flex>
              ))}
            </VStack>
          </Box>
        )}
      </VStack>
    </Box>
  );
};

export default EventDetails;
