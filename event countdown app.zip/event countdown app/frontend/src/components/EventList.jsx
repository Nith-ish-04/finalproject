import { useState, useEffect } from 'react'
import { Flex, SimpleGrid, Text, Heading, useToast } from '@chakra-ui/react'
import EventCard from './EventCard'
import { getEvents } from '../services/api'

const MOCK_USER_ID = 'user123'

const EventList = () => {
  const [events, setEvents] = useState([])
  const [loading, setLoading] = useState(true)
  const toast = useToast()

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const data = await getEvents(MOCK_USER_ID)
        setEvents(data)
      } catch (error) {
        toast({
          title: 'Error fetching events',
          description: error.message,
          status: 'error',
          duration: 3000,
          isClosable: true,
        })
      } finally {
        setLoading(false)
      }
    }

    fetchEvents()
  }, [toast])

  if (loading) {
    return (
      <Flex w="100%" maxW="1400px" justify="center" p={4}>
        <Text>Loading events...</Text>
      </Flex>
    )
  }

  return (
    <Flex w="100%" maxW="1400px" direction="column" p={4}>
      <Heading mb={6}>Your Events</Heading>
      {events.length === 0 ? (
        <Text>No events found. Create your first event!</Text>
      ) : (
        <SimpleGrid 
          columns={{ base: 1, md: 2, lg: 3, xl: 4 }} 
          spacing={6}
          w="100%"
        >
          {events.map((event) => (
            <EventCard key={event._id} event={event} />
          ))}
        </SimpleGrid>
      )}
    </Flex>
  )
}

export default EventList
