import { Flex, Button, Heading } from '@chakra-ui/react'
import { Link as RouterLink } from 'react-router-dom'

const Navbar = () => {
  return (
    <Flex
      as="nav"
      w="100%"
      h="16"
      bg="white"
      boxShadow="sm"
      px={4}
      align="center"
      justify="space-between"
      position="sticky"
      top="0"
      zIndex="sticky"
    >
      <Heading as={RouterLink} to="/" size="lg" color="purple.600">
        Event Countdown
      </Heading>
      <Button
        as={RouterLink}
        to="/create"
        colorScheme="purple"
        variant="solid"
      >
        Create Event
      </Button>
    </Flex>
  )
}

export default Navbar
