import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import {
  Box,
  VStack,
  Heading,
  Text,
  Progress,
  SimpleGrid,
  useToast,
} from '@chakra-ui/react'
import { getEventByShareLink } from '../services/api'
import { useCountdown } from '../hooks/useCountdown'

const SharedEvent = () => {
  const { shareLink } = useParams()
  const toast = useToast()
  const [event, setEvent] = useState(null)
  const [loading, setLoading] = useState(true)
  const { days, hours, minutes, seconds, progress } = useCountdown(
    event?.date || new Date()
  )

  useEffect(() => {
    const fetchEvent = async () => {
      try {
        const data = await getEventByShareLink(shareLink)
        setEvent(data)
      } catch (error) {
        toast({
          title: 'Error fetching event',
          description: error.message,
          status: 'error',
          duration: 3000,
        })
      } finally {
        setLoading(false)
      }
    }

    fetchEvent()
  }, [shareLink, toast])

  if (loading) {
    return <Text>Loading shared event...</Text>
  }

  if (!event) {
    return <Text>Event not found or is private</Text>
  }

  return (
    <Box
      p={6}
      bg={event.theme.backgroundColor}
      color={event.theme.textColor}
      borderRadius="lg"
      shadow="md"
    >
      <VStack spacing={6} align="stretch">
        <Heading size="xl">{event.title}</Heading>
        <Text fontSize="lg">{event.description}</Text>

        <Box textAlign="center" py={6}>
          <Progress value={progress} size="lg" colorScheme="purple" mb={4} />
          <SimpleGrid columns={4} spacing={4}>
            <Box>
              <Text fontSize="4xl" fontWeight="bold">
                {days}
              </Text>
              <Text>Days</Text>
            </Box>
            <Box>
              <Text fontSize="4xl" fontWeight="bold">
                {hours}
              </Text>
              <Text>Hours</Text>
            </Box>
            <Box>
              <Text fontSize="4xl" fontWeight="bold">
                {minutes}
              </Text>
              <Text>Minutes</Text>
            </Box>
            <Box>
              <Text fontSize="4xl" fontWeight="bold">
                {seconds}
              </Text>
              <Text>Seconds</Text>
            </Box>
          </SimpleGrid>
        </Box>

        {event.milestones.length > 0 && (
          <Box>
            <Heading size="md" mb={4}>
              Milestones
            </Heading>
            <VStack align="stretch" spacing={3}>
              {event.milestones.map((milestone) => (
                <Box
                  key={milestone._id}
                  p={3}
                  bg={event.theme.backgroundColor}
                  borderRadius="md"
                  borderWidth="1px"
                >
                  <Text>
                    {milestone.title} -{' '}
                    {milestone.completed ? 'Completed' : 'Pending'}
                  </Text>
                  <Text fontSize="sm">
                    {new Date(milestone.dueDate).toLocaleDateString()}
                  </Text>
                </Box>
              ))}
            </VStack>
          </Box>
        )}
      </VStack>
    </Box>
  )
}

export default SharedEvent
