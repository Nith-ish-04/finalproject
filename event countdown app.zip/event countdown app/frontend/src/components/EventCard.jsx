import { Box, Heading, Text, VStack, Badge, Progress } from '@chakra-ui/react';
import { Link } from 'react-router-dom';
import useCountdown from '../hooks/useCountdown';

const EventCard = ({ event }) => {
  const { timeLeft, isExpired } = useCountdown(event.date);

  const formatTimeValue = (value, unit) => {
    if (!value && value !== 0) return '';
    return `${value} ${unit}${value === 1 ? '' : 's'}`;
  };

  const getTimeString = () => {
    if (isExpired) {
      return 'Event has ended';
    }

    const timeStrings = [];
    if (timeLeft.days) timeStrings.push(formatTimeValue(timeLeft.days, 'day'));
    if (timeLeft.hours) timeStrings.push(formatTimeValue(timeLeft.hours, 'hour'));
    if (timeLeft.minutes) timeStrings.push(formatTimeValue(timeLeft.minutes, 'minute'));
    if (timeLeft.seconds) timeStrings.push(formatTimeValue(timeLeft.seconds, 'second'));

    return timeStrings.join(', ') || 'Now';
  };

  const getProgress = () => {
    if (isExpired) return 100;
    const totalDuration = new Date(event.date) - new Date(event.createdAt);
    const elapsed = new Date() - new Date(event.createdAt);
    return Math.min(100, (elapsed / totalDuration) * 100);
  };

  return (
    <Box
      as={Link}
      to={`/event/${event._id}`}
      p={5}
      shadow="md"
      borderWidth="1px"
      borderRadius="lg"
      bg={event.theme?.backgroundColor || 'white'}
      color={event.theme?.textColor || 'black'}
      transition="transform 0.2s"
      _hover={{ transform: 'scale(1.02)' }}
    >
      <VStack align="stretch" spacing={3}>
        <Heading size="md">{event.title}</Heading>
        <Text noOfLines={2}>{event.description}</Text>
        
        <Box>
          <Text fontSize="sm" mb={1}>Time Remaining:</Text>
          <Text fontWeight="bold" color={isExpired ? 'red.500' : 'inherit'}>
            {getTimeString()}
          </Text>
        </Box>

        <Progress
          value={getProgress()}
          size="sm"
          colorScheme={isExpired ? 'red' : 'purple'}
          borderRadius="full"
        />

        <Box>
          {event.milestones?.length > 0 && (
            <Badge colorScheme="purple">
              {event.milestones.length} milestone{event.milestones.length === 1 ? '' : 's'}
            </Badge>
          )}
          {event.isPublic && (
            <Badge colorScheme="green" ml={2}>
              Public
            </Badge>
          )}
        </Box>
      </VStack>
    </Box>
  );
};

export default EventCard;
