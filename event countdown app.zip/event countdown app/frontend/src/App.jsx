import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { ChakraProvider, Flex } from '@chakra-ui/react'
import Navbar from './components/Navbar'
import EventList from './components/EventList'
import CreateEvent from './components/CreateEvent'
import EventDetails from './components/EventDetails'
import SharedEvent from './components/SharedEvent'

function App() {
  return (
    <ChakraProvider>
      <Router>
        <Flex 
          direction="column" 
          minH="100vh" 
          w="100vw"
          bg="gray.50"
        >
          <Navbar />
          <Flex 
            flex="1"
            w="100%"
            justify="center"
            align="start"
            p={4}
            overflowY="auto"
          >
            <Routes>
              <Route path="/" element={<EventList />} />
              <Route path="/create" element={<CreateEvent />} />
              <Route path="/event/:id" element={<EventDetails />} />
              <Route path="/share/:shareLink" element={<SharedEvent />} />
            </Routes>
          </Flex>
        </Flex>
      </Router>
    </ChakraProvider>
  )
}

export default App
